-- F�rat �niversitesi, Bilgisayar M�hendisli�i
INSERT INTO Uyeler (O_id, O_ad, O_soyad, Bol_id) VALUES
(71, 'Ahmet', 'Kaya', 16),
(72, 'Mehmet', 'Y�ld�r�m', 16),
(73, 'Ay�e', 'Ko�', 16),
(74, 'Fatma', 'Ayd�n', 16),
(75, 'Ali', '�elik', 16),
(76, 'Zeynep', '�ahin', 16),
(77, 'H�seyin', 'Bayrak', 16),
(78, 'Seda', 'Karakaya', 16),
(79, 'Hasan', 'Demir', 16),
(80, 'Elif', 'G�ne�', 16);"

-- F�rat �niversitesi, Elektrik-Elektronik M�hendisli�i
INSERT INTO Uyeler (O_id, O_ad, O_soyad, Bol_id) VALUES
(81, 'Burak', 'Eren', 17),
(82, 'Ece', 'Kaplan', 17),
(83, 'Emre', 'Sar�kaya', 17),
(84, 'Hakan', 'Altun', 17),
(85, 'B��ra', 'G�zel', 17),
(86, 'Cem', 'Yavuz', 17),
(87, 'Serkan', '�elik', 17),
(88, '�zge', 'Tan', 17),
(89, 'Merve', 'Aksoy', 17),
(90, 'Mert', 'Korkmaz', 17);