
INSERT INTO Etkinlikler (E_id, E_ad, Ot_id) VALUES
(1, 'Yaz�l�m Geli�tirme Hackathon', 21), 
(2, 'Siber G�venlik Konferans�', 22),        
(3, 'Kitap Okuma Etkinli�i', 23),            
(4, 'Google Developer Group Meetup', 24),    
(5, 'Tarih ve K�lt�r Semineri', 25);          