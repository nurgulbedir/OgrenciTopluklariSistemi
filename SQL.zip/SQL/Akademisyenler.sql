-- F�rat �niversitesi (17)
INSERT INTO Akademisyenler (A_id, A_ad, A_soyad, A_unvan, Bol_id) VALUES
(73, 'Mehmet', 'Karak�se', 'Profes�r', 16),
(74, 'Mehmet', 'Kaya', 'Profes�r', 16),
(75, 'Burhan', 'Ergen', 'Profes�r', 16),
(76, '�lhan', 'Ayd�n', 'Profes�r', 16),
(77, 'Ahmet Bedri', '�zer', 'Profes�r', 16),
(78, 'Erkan', 'Duman', 'Do�ent', 16),
(79, 'Erhan', 'Ak�n', 'Do�ent', 16),
(80, 'G�ng�r', 'Y�ld�r�m', 'Do�ent', 16),
(81, 'Ebubekir', 'Erdem', 'Do�ent', 16),
(82, 'Ahmet', 'Kara', 'Doktor ��retim �yesi', 16);




