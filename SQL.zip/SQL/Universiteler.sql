INSERT INTO Universiteler (U_id, U_ad, S_id) VALUES
-- Marmara B�lgesi
(1, 'Bo�azi�i �niversitesi', 1),
(2, '�stanbul Teknik �niversitesi', 1),
(3, 'Ko� �niversitesi', 1),
(4, 'Sabanc� �niversitesi', 1),
(5, 'Uluda� �niversitesi', 7),

-- Ege B�lgesi
(6, 'Ege �niversitesi', 12),
(7, 'Dokuz Eyl�l �niversitesi', 12),
(8, 'Pamukkale �niversitesi', 17),

-- Akdeniz B�lgesi
(9, 'Akdeniz �niversitesi', 20),
(10, '�ukurova �niversitesi', 22),

-- �� Anadolu B�lgesi
(11, 'Orta Do�u Teknik �niversitesi', 28),
(12, 'Ankara �niversitesi', 28),
(13, 'Hacettepe �niversitesi', 28),

-- Karadeniz B�lgesi
(14, 'Karadeniz Teknik �niversitesi', 40),
(15, 'Ondokuz May�s �niversitesi', 45),

-- Do�u Anadolu B�lgesi
(16, 'Atat�rk �niversitesi', 56),
(17, 'F�rat �niversitesi', 61),

-- G�neydo�u Anadolu B�lgesi
(18, 'Gaziantep �niversitesi', 70),
(19, 'Dicle �niversitesi', 72);