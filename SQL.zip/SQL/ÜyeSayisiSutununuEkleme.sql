ALTER TABLE OgrenciTopluluklari
ADD Uye_Sayisi INT DEFAULT 0;




